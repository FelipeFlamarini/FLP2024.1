# ex01 ---------------------------------
import ex01

lista1 = ('morango', 'maçã', 'abacate', 'abacaxi')
lista2 = ('uva', 'pêra', 'acerola', 'amora')
print(ex01.combinar_listas(lista1, lista2))

print()
# ex02 ---------------------------------
import ex02

print(ex02.contida("abcedario","abcd"))
print(ex02.contida("abcedario","abcdef"))

print()
# ex03 ---------------------------------
import ex03
